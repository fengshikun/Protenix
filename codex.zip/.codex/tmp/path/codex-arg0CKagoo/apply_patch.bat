@echo off
"c:\Users\Administrator\.vscode\extensions\openai.chatgpt-0.4.60-win32-x64\bin\windows-x86_64\codex.exe" --codex-run-as-apply-patch %*
